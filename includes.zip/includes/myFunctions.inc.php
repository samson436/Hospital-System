<?php

function emptyInputsApt($patName, $patPhoneNo, $patEmail, $patResidence, $patAge, $patGender, $opCategory, $attendingDoc)
{
    $results = "";
    if (
        empty($patName) || empty($patPhoneNo) || empty($patEmail) || empty($patResidence) ||  empty($patAge) || empty($patGender) || empty($opCategory)  || empty($attendingDoc)
    ) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function isValidName($patName)
{
    $results = "";
    if (!preg_match("/^[a-zA-Z-' ]*$/", $patName)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function notNumber($patPhoneNo, $patAge)
{
    $results = "";
    if (!preg_match("/^[0-9]*$/", $patPhoneNo) || !preg_match("/^[0-9]*$/", $patAge)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function isValidEmail($patEmail)
{
    $results = "";
    if (!filter_var($patEmail, FILTER_VALIDATE_EMAIL)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function bookApt($conn, $patName, $patPhoneNo, $patEmail, $patResidence, $patAge, $patGender, $opCategory, $attendingDoc)
{
    $sql = "INSERT INTO patientvisitdetails(pntName, pntPhoneNo, pntEmail, pntResidence, pntAge, pntGender, pntOpCategory, docName) VALUES(?, ?, ?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../appointments.php?error=stmtFailed");
        exit();
    }
    //IF SSQL STMT DOESNT FAIL
    mysqli_stmt_bind_param($stmt, "sississs", $patName, $patPhoneNo, $patEmail, $patResidence, $patAge, $patGender, $opCategory, $attendingDoc);
    mysqli_stmt_execute($stmt);
    //CLOSE DB CONNECTION
    mysqli_stmt_close($stmt);
    header("location: ../appointments.php?error=success");
    exit();
}

//CLINIC >>>PHP><<ADD NEW
function isEmptyClinic($clinicName)
{
    $results = "";
    if (empty($clinicName)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function invalidClinicName($clinicName)
{
    $results = "";
    if (!preg_match("/^[a-zA-Z-' ]*$/", $clinicName)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
function clinicExist($conn, $clinicName)
{
    $results = "";
    $sql = "SELECT * FROM clinics WHERE opCategory=?;";
    $stmt = mysqli_stmt_init($conn);
    #check for sql error
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../clinic.php?error=stmtFailed");
        exit();
    }
    #if no errors
    mysqli_stmt_bind_param($stmt, "s", $clinicName);
    mysqli_stmt_execute($stmt);
    #GET THE RESULTS
    $reslutingData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($reslutingData)) {
        return $row;
    } else {
        $results = false;
        return $results;
    }
    mysqli_stmt_close($stmt);
}
//ADD CLINIC
function createClinic($conn, $clinicName)
{
    $sql = "INSERT INTO clinics(opCategory) VALUES(?);";
    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../clinic.php?error=stmtFailed");
        exit();
    }
    //IF SUCCESS WE INSERT
    mysqli_stmt_bind_param($stmt, "s", $clinicName);
    mysqli_stmt_execute($stmt);
    //CLOSE CONNECTION
    mysqli_stmt_close($stmt);
    header("location: ../clinic.php?error=success");
    exit();
}

//DOCTORS<<<>PHP>>ADD<<>>NEW<<<>>DOC
function isEmptyVal($docName, $docEmail, $docDept)
{
    $results = "";
    if (empty($docName) || empty($docEmail) || empty($docDept)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}

function invaliDocName($docName)
{
    $results = "";
    if (!preg_match("/^[a-zA-Z-' ]*$/", $docName)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}

function invalidDocMail($docEmail)
{
    $results = "";
    if (!filter_var($docEmail, FILTER_VALIDATE_EMAIL)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}

function docExist($conn, $docName, $docEmail)
{
    $results = "";
    $sql = "SELECT * FROM doctors WHERE docName=? AND docEmail=?;";
    $stmt = mysqli_stmt_init($conn);
    #check for sql error
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../doctor.php?error=stmtFailed");
        exit();
    }
    #if no errors
    mysqli_stmt_bind_param($stmt, "ss", $docName, $docEmail);
    mysqli_stmt_execute($stmt);
    #GET THE RESULTS
    $reslutingData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($reslutingData)) {
        return $row;
    } else {
        $results = false;
        return $results;
    }
    mysqli_stmt_close($stmt);
}



//ADD<<>>DOCTOR
function createDoc($conn, $docName, $docEmail, $docDept)
{
    $sql = "INSERT INTO doctors(docName, docEmail, docSpec) VALUES(?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);

    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../doctor.php?error=stmtFailed");
        exit();
    }
    //IF SUCCESS WE INSERT
    mysqli_stmt_bind_param($stmt, "sss", $docName, $docEmail, $docDept);
    mysqli_stmt_execute($stmt);
    //CLOSE CONNECTION
    mysqli_stmt_close($stmt);
    header("location: ../doctor.php?error=success");
    exit();
}
//---CREATE-ADMIN.PHP-------

function emptyInputsAdmin($fname, $username, $email, $pwd, $conPwd)
{
    $result = "";
    if (empty($fname) || empty($username) || empty($email) || empty($pwd) || empty($conPwd)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
function invalidAdmin($fname, $username)
{
    $result = "";
    if (!preg_match("/^[a-zA-Z-' ]*$/", $fname) || !preg_match("/^[a-zA-Z-' ]*$/", $username)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
function invalidEmail($email)
{
    $results = "";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $results = true;
    } else {
        $results = false;
    }
    return $results;
}
//checking wether passwords do matc  
function pwdMatch($pwd, $conPwd)
{
    $result =  "";
    if ($pwd !== $conPwd) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
function adminExist($conn, $username, $email)
{
    $result = "";
    $sql = "SELECT * FROM admins WHERE loginName=? OR adminEmail=?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../create-admin.php?error=stmtfailed");
        exit();
    }
    #if no sql errors  then pass email or uid to db
    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);
    #grambing the results
    $resultData = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($resultData)) {
        return $row;
    } else {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}
//-----Create nNEW ADMIN-------
function createAdmin($conn, $fname, $username, $email, $pwd)
{
    $sql = "INSERT INTO admins(fullName, loginName, adminEmail, pwd) VALUES(?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../create-admin.php?error=stmtfailed");
        exit();
    }
    //hash password
    $pwdHashed = password_hash($pwd, PASSWORD_DEFAULT);

    #if no sql errors  then insert data to table
    mysqli_stmt_bind_param($stmt, "ssss", $fname, $username, $email, $pwdHashed);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("location: ../create-admin.php?error=none");
    exit();
}


//---wORKING ON LOGIN FUNCTIONALITY------
function emptyInputsLogin($username, $pwd)
{
    $result = "";
    if (empty($username) || empty($pwd)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
function loginUser($conn, $username, $pwd)
{

    $adminExist = adminExist($conn, $username, $username);
    if ($adminExist === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }

    #checking the password
    $pwdHashed = $adminExist["pwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

     if ($checkPwd === false) {
        header("location: ../login.php?error=wrongPwd");
        exit();
    } elseif ($checkPwd === true) {
        session_start();
        $_SESSION["adminId"] = $adminExist["adminID"];
        $_SESSION["adminName"] = $adminExist["loginName"];
        header("location: ../admin.php");
        exit();
    } else {
        header("location: ../index.html");
        exit();
    }
} 

//UPDATE FUNCTIONS 

function emptyUpdate($fname, $username, $email) {
    $result="";

    if (empty($fname) || empty($username) || empty($email)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}

//----CREATE---FEEDBACK-----
function isValidFed($name, $message) {
    $result="";
    if (!preg_match("/^[a-zA-Z-' ]*$/", $name) || !preg_match("/^[a-zA-Z-' ]*$/", $message)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}

function createFeedback($conn, $name, $email, $message) {
    $sql="INSERT INTO feedbacks(fullName, email, feedMessage) VALUES(?,?,?);";
    $stmt=mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: ../feed.php?error=stmtFailed");
        exit();
    }
    //if no errors insert
    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $message);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../feed.php?error=thankYou");
    exit();
}