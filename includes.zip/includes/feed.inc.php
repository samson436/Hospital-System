<?php

if (isset($_POST['submit-feed'])) {
    $name=$_POST['fname'];
    $email=$_POST['email'];
    $message=$_POST['messu'];

    //INCLUDE DEPENDANCIES

    require_once 'dbh.inc.php';
    require_once 'myFunctions.inc.php';

    if (isValidFed($name, $message) !==false) {
        header("location: ../feed.php?error=invalidInput");
        exit();
    }
    if (invalidEmail($email) !==false){
        header("location: ../feed.php?error=invalidEmail");
        exit();
    }
    createFeedback($conn, $name, $email, $message);

} else {
    header("location: ../feed.php");
    exit();
}