<?php

if (isset($_POST['submit-login'])) {
    $username = $_POST["uid"];
    $pwd = $_POST["pwd"];

    #includind db connection and functions
    include_once 'dbh.inc.php';
    include_once 'myFunctions.inc.php';


    /*---wORKING ON LOGIN FUNCTIONALITY------
function emptyInputsLogin($username, $pwd)
{
    $result = "";
    if (empty($username) || empty($pwd)) {
        $result = true;
    } else {
        $result = false;
    }
    return $result;
}
function loginUser($conn, $username, $pwd)
{

    $adminExist = adminExist($conn, $username, $username);
    if ($adminExist === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }

    #checking the password
    $pwdHashed = $adminExist["pwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

     if ($checkPwd === false) {
        // echo $checkPwd;
        header("location: ../login.php?error=wrongPwd");
        exit();
    } elseif ($checkPwd === true) {
        session_start();
        $_SESSION["adminId"] = $adminExist["adminID"];
        $_SESSION["adminName"] = $adminExist["loginName"];
        header("location: ../admin.php");
        exit();
    } 
} 
*/


    #error handling
    if (emptyInputsLogin($username, $pwd) !== false) {
        header("location: ../login.php?error=emptyinputs");
        exit();
    }
    loginUser($conn, $username, $pwd);
} else {
    header("location: ../login.php");
    exit();
}
