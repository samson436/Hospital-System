<?php

$serverName = "localhost:3308";
$dBUsername = "root";
$dBPassword="";
$dBName = "matuudb";


$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
    die("connnection failed: " . mysqli_connect_error());
}
