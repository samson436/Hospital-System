<?php

if (isset($_POST['submit-update-doc'])) {
    $docName = $_POST['fname'];
    $docEmail = $_POST['email'];
    $docDept = $_POST['speciality'];
    $docId=$_POST['id'];

    //INCLUDE<<>>DEPENDANCIES
    require_once 'dbh.inc.php';
    require_once 'myFunctions.inc.php';

    //FORM<<>>VALIDATION
    if (isEmptyVal($docName, $docEmail, $docDept) !== false) {
        header("location: ../doctor.php?error=emptyInputs");
        exit();
    }
    if (invaliDocName($docName) !== false) {
        header("location: ../doctor.php?error=invalidName");
        exit();
    }
    if (invalidDocMail($docEmail) !== false) {
        header("location: ../doctor.php?error=invalidEmail");
        exit();
    }
    if (docExist($conn, $docName, $docEmail) !== false) {
        header("location: ../doctor.php?error=docExist");
        exit();
    }

     //>>>>>UPDATE DOCTOR>>>
     $sql= "UPDATE doctors SET docName=?, docEmail=?, docSpec=? WHERE docID=?;";
     $stmt=mysqli_stmt_init($conn);
     if (!mysqli_stmt_prepare($stmt, $sql)) {
         header("location: edit-doc.php?error=stmtFailed");
         exit();
     }
     mysqli_stmt_bind_param($stmt, 'sssi', $docName, $docEmail, $docDept, $docId);
     mysqli_stmt_execute($stmt);
     mysqli_stmt_close($stmt);
     header("location: ../vDoc.php?error=success");
     exit();
    
} else {
    header("location: ../doctor.php");
    exit();
}
