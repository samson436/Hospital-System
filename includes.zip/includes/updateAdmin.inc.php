<?php

if (isset($_POST['submit-update-admin'])) {
    $fname = $_POST['fname'];
    $username = $_POST['uid'];
    $email = $_POST['email'];
    $adminId = $_POST['id'];

    //INCLUDE DATABASE CONNECTION
    include_once 'dbh.inc.php';
    include_once 'myFunctions.inc.php';

    //error handling
    if (emptyUpdate($fname, $username, $email) !==false) {
        header("location: ../edit-admin.php?error=entervalidname");
        exit();
    }
    if (invalidAdmin($fname, $username) !== false) {
        header("location: ../edit-admin.php?error=entervalidname");
        exit();
    }
    if (invalidEmail($email) !== false) {
        header("location: ../edit-admin.php?error=enterValidEmail");
        exit();
    }
    if (adminExist($conn, $username, $email) !== false) {
        header("location: ../edit-admin.php?error=emailExistorAdminExist");
        exit();
    }
     //>>>>>UPDATE ADMIN>>>
       $sql= "UPDATE admins SET fullName=?, loginName=?, adminEmail=? WHERE adminID=?;";
     $stmt=mysqli_stmt_init($conn);
     if (!mysqli_stmt_prepare($stmt, $sql)) {
         header("location: edit-clinic.php?error=stmtFailed");
         exit();
     }
     mysqli_stmt_bind_param($stmt, 'sssi', $fname, $username, $email, $adminId);
     mysqli_stmt_execute($stmt);
     mysqli_stmt_close($stmt);
     header("location: ../vAdmin.php?error=success");
     exit();
} else {
    header("location: ../vAdmin.php");
    exit();
}
