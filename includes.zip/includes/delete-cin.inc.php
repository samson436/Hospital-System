<?php
require_once 'dbh.inc.php';

// DELETING CLINIC
if (isset($_POST['submit-del-clinic'])) {
    $cintId=$_POST['submit-del-clinic'];
    //querry
    $sql="DELETE FROM clinics WHERE cintID=?;";
    $stmt=mysqli_stmt_init($conn);
    // if not connected
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: vClinic.php?error=stmtFailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, 'i', $cintId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../vClinic.php?error=done");
    exit();

} else{
    header("location: ../vClinic.php");
    exit();
}
