<?php


require_once 'dbh.inc.php';

// DELETING ADMIN
if (isset($_POST['submit-del-admin'])) {
    $adminId=$_POST['submit-del-admin'];
    //querry
    $sql="DELETE FROM admins WHERE adminID=?;";
    $stmt=mysqli_stmt_init($conn);
    // if not connected
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: vAdmin.php?error=stmtFailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, 'i', $adminId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../vAdmin.php?error=done");
    exit();

} else{
    header("location: ../vAdmin.php");
    exit();
}