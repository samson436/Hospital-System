<?php


require_once 'dbh.inc.php';


// DELETING DOCTOR
if (isset($_POST['submit-del-doc'])) {
    $docId=$_POST['submit-del-doc'];
    //querry
    $sql="DELETE FROM doctors WHERE docID=?;";
    $stmt=mysqli_stmt_init($conn);
    // if not connected
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: vDoc.php?error=stmtFailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, 'i', $docId);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    header("location: ../vDoc.php?error=done");
    exit();

} else{
    header("location: ../vDoc.php");
    exit();
}