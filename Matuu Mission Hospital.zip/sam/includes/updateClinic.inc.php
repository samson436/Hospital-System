<?php

if (isset($_POST['submit-update-clinic'])) {
    $clinicName = $_POST['opCategory'];
    $cintId =$_POST['id'];
    //INCLUDE DEPENDANCIE
    require_once 'dbh.inc.php';
    require_once 'myFunctions.inc.php';
    //FORM VALADATION
    if (isEmptyClinic($clinicName) !== false) {
        header("location: ../clinic.php?error=emptyInputs");
        exit();
    }
    if (invalidClinicName($clinicName) !== false) {
        header("location: ../clinic.php?error=invalidName");
        exit();
    }
        //>>>>>UPDATE CLINIC>>>
        $sql= "UPDATE clinics SET opCategory=? WHERE cintID=?;";
        $stmt=mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: edit-clinic.php?error=stmtFailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, 'si', $clinicName, $cintId);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        header("location: ../vClinic.php?error=success");
        exit();

} else {
    header("location : ../vClinic.php");
    exit();
}
