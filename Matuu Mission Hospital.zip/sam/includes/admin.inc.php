<?php

if (isset($_POST['submit-create'])) {
    $fname = $_POST['fname'];
    $username = $_POST['uid'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $conPwd = $_POST['conPwd'];

    //INCLUDE DATABASE CONNECTION
    include_once 'dbh.inc.php';
    include_once 'myFunctions.inc.php';

    //error handling
    if (emptyInputsAdmin($fname, $username, $email, $pwd, $conPwd) !== false) {
        header("location: ../create-admin.php?error=emptyinputs");
        exit();
    }
    if (invalidAdmin($fname, $username) !== false) {
        header("location: ../create-admin.php?error=entervalidname");
        exit();
    }
    if (invalidEmail($email) !== false) {
        header("location: ../create-admin.php?error=enterValidEmail");
        exit();
    }
    if (pwdMatch($pwd, $conPwd) !== false) {
        header("location: ../create-admin.php?error=pwdDonotMatch");
        exit();
    }
    if (adminExist($conn, $username, $email) !== false) {
        header("location: ../create-admin.php?error=emailExistorAdminExist");
        exit();
    }
    createAdmin($conn, $fname, $username, $email, $pwd);
} else {
    header("location: ../create-admin.php");
    exit();
}
