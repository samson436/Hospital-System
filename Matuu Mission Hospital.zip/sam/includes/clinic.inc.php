<?php

if (isset($_POST['submit-clinic'])) {
    $clinicName = $_POST['opCategory'];
    //INCLUDE DEPENDANCIE
    require_once 'dbh.inc.php';
    require_once 'myFunctions.inc.php';
    //FORM VALADATION
    if (isEmptyClinic($clinicName) !== false) {
        header("location: ../clinic.php?error=emptyInputs");
        exit();
    }
    if (invalidClinicName($clinicName) !== false) {
        header("location: ../clinic.php?error=invalidName");
        exit();
    }
    if (clinicExist($conn, $clinicName)) {
        header("location: ../clinic.php?error=clinicExist");
        exit();
    }
    createClinic($conn, $clinicName);
} else {
    header("location : ../clinic.php");
    exit();
}
