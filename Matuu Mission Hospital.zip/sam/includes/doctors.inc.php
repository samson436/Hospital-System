<?php

if (isset($_POST['submit-doc'])) {
    $docName = $_POST['fname'];
    $docEmail = $_POST['email'];
    $docDept = $_POST['speciality'];

    //INCLUDE<<>>DEPENDANCIES
    require_once 'dbh.inc.php';
    require_once 'myFunctions.inc.php';

    //FORM<<>>VALIDATION
    if (isEmptyVal($docName, $docEmail, $docDept) !== false) {
        header("location: ../doctor.php?error=emptyInputs");
        exit();
    }
    if (invaliDocName($docName) !== false) {
        header("location: ../doctor.php?error=invalidName");
        exit();
    }
    if (invalidDocMail($docEmail) !== false) {
        header("location: ../doctor.php?error=invalidEmail");
        exit();
    }
    if (docExist($conn, $docName, $docEmail) !== false) {
        header("location: ../doctor.php?error=docExist");
        exit();
    }
    if (createDoc($conn, $docName, $docEmail, $docDept)) {
    }
} else {
    header("location: ../doctor.php");
    exit();
}
