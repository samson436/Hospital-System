<?php

if (isset($_POST['submit-apt'])) {
    //DECLARE VARIABLES
    $patName = $_POST['fname'];
    $patPhoneNo = $_POST['phonenumber'];
    $patEmail = $_POST['email'];
    $patResidence = $_POST['residence'];
    $patAge = $_POST['age'];
    $patGender = $_POST['gender'];
    $opCategory = $_POST['clinic'];
    $attendingDoc = $_POST['doc'];


    //INCLUDE DEPENDANCIES....
    include_once 'dbh.inc.php';
    include_once 'myFunctions.inc.php';
    //FORM VALIDATION....
    if (emptyInputsApt($patName, $patPhoneNo, $patEmail, $patResidence, $patAge, $patGender, $opCategory, $attendingDoc) !== false) {
        header("location: ../appointments.php?error=emptyInputs");
        exit();
    }
    if (isValidName($patName) !== false) {
        header("location: ../appointments.php?error=invalidName");
        exit();
    }
    if (notNumber($patPhoneNo, $patAge)) {
        header("location: ../appointments.php?error=invalidNumber");
        exit();
    }
    if (isValidEmail($patEmail) !== false) {
        header("location: ../appointments.php?error=invalidEmail");
        exit();
    }
    bookApt($conn, $patName, $patPhoneNo, $patEmail, $patResidence, $patAge, $patGender, $opCategory, $attendingDoc);
} else {
    header("location: ../appointments.php");
    exit();
}
