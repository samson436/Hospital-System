<?php

$serverName = "localhost";
$dbUsername = "matuumis_administrator";
$dbPassword = "Matuu@2023";
$dbName = "matuumis_matuuDB";


$conn = mysqli_connect($serverName, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
    die("connnection failed: " . mysqli_connect_error());
}
